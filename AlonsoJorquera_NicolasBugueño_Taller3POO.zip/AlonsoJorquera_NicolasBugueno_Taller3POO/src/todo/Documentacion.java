package todo;

public class Documentacion extends Tarea {

	public Documentacion(Proyecto proyecto, String id, String tipo, String descripcion, String estado,
			Usuario usuarioResponsable, String complejidad, String fecha) {
		super(proyecto, id, tipo, descripcion, estado, usuarioResponsable, complejidad, fecha);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void aceptar(VisitorTareas v) {
	    v.visitarDocumentacion(this); 
	}

}
