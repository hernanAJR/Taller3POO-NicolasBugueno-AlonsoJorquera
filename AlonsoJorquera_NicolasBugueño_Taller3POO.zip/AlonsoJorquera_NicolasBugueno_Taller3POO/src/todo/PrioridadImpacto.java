package todo;

import java.util.ArrayList;

public class PrioridadImpacto implements PrioridadStrategy {
	//Ordenar segun impacto en proyecto
    @Override
    public void ordenar(ArrayList<Tarea> tareas) {
        for (int i = 0; i < tareas.size() - 1; i++) {
            for (int j = 0; j < tareas.size() - i - 1; j++) {
                int p1 = obtenerPrioridad(tareas.get(j).getTipo());
                int p2 = obtenerPrioridad(tareas.get(j+1).getTipo());
                if (p1 > p2) {
                    Tarea temp = tareas.get(j);
                    tareas.set(j, tareas.get(j+1));
                    tareas.set(j+1, temp);
                }
            }
        }
    }

    private int obtenerPrioridad(String tipo) {
        switch (tipo.toLowerCase()) {
            case "bug": return 1; // alta prioridad
            case "feature": return 2; // media
            case "documentacion": return 3; // baja
            default: return 4;
        }
    }
}
