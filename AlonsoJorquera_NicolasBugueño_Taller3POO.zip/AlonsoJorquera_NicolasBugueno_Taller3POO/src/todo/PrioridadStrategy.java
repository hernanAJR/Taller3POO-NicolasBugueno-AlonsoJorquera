package todo;

import java.util.ArrayList;
//STRATEGY (Ordenar las listas de tareas)
public interface PrioridadStrategy {
    void ordenar(ArrayList<Tarea> tareas);
}

