package todo;

public class Admin extends Usuario {
	private String rol;
    public Admin(String nombre, String contraseña) {
        super(nombre, contraseña);
        this.rol="admin";
    }

    @Override
    public void mostrarMenu() {
        System.out.println("Menú Administrador:");
        System.out.println("1. Crear Proyecto");
        System.out.println("2. Asignar Tarea");
        System.out.println("3. Generar Reporte");
        System.out.println("4. Salir");
    }
}

