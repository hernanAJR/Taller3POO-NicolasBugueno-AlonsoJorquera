package todo;

import java.util.ArrayList;

public class PrioridadComplejidad implements PrioridadStrategy {
	//Ordenar por complejidad
    @Override
    public void ordenar(ArrayList<Tarea> tareas) {
        for (int i = 0; i < tareas.size() - 1; i++) {
            for (int j = 0; j < tareas.size() - i - 1; j++) {
                int c1 = obtenerValorComplejidad(tareas.get(j).getComplejidad());
                int c2 = obtenerValorComplejidad(tareas.get(j+1).getComplejidad());
                if (c1 > c2) {
                    Tarea temp = tareas.get(j);
                    tareas.set(j, tareas.get(j+1));
                    tareas.set(j+1, temp);
                }
            }
        }
    }

    private int obtenerValorComplejidad(String complejidad) {
        switch (complejidad.toLowerCase()) {
            case "alta": return 1;
            case "media": return 2;
            case "baja": return 3;
            default: return 4;
        }
    }
}

