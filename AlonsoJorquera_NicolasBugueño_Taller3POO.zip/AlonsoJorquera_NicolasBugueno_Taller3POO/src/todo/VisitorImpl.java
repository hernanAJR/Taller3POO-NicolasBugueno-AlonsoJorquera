package todo;

public class VisitorImpl implements VisitorTareas {

    @Override
    public void visitarBug(Bug b) {
        System.out.println("Bug [" + b.getId() + "]  Estado: " + b.getEstado() +
                           " | Criticidad alta para el proyecto.");
    }

    @Override
    public void visitarFeature(Feature f) {
        System.out.println("Feature [" + f.getId() + "] → Responsable: " +
                           f.getUsuarioResponsable().getNombre() +
                           " | Complejidad: " + f.getComplejidad());
    }

    @Override
    public void visitarDocumentacion(Documentacion d) {
        System.out.println("Documentación [" + d.getId() + "] → " +
                           d.getDescripcion() + " | Fecha: " + d.getFecha());
    }
}

