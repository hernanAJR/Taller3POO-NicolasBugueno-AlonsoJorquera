package todo;

import java.util.ArrayList;

public class Proyecto {
    private String id;
    private Usuario usuarioResponsable;
    private ArrayList<Tarea> tareasProyecto;

    public Proyecto(String id, Usuario usuarioResponsable) {
        this.id = id;
        this.usuarioResponsable = usuarioResponsable;
        this.tareasProyecto = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public Usuario getUsuarioResponsable() {
        return usuarioResponsable;
    }

    public ArrayList<Tarea> getTareasProyecto() {
        return tareasProyecto;
    }

    public void agregarTarea(Tarea tarea) {
        tareasProyecto.add(tarea);
    }

    public void mostrarTareas() {
        for (Tarea t : tareasProyecto) {
            System.out.println(t);
        }
    }
    //Ordenar las tareas USAR STRATEGY!!
    public void ordenarTareas(String estrategia) {
        PrioridadStrategy strategy;

        switch (estrategia.toLowerCase()) {
            case "fecha":
                strategy = new PrioridadFecha();
                break;
            case "impacto":
                strategy = new PrioridadImpacto();
                break;
            case "complejidad":
                strategy = new PrioridadComplejidad();
                break;
            default:
                System.out.println("Estrategia desconocida.");
                return;
        }

        strategy.ordenar(tareasProyecto);
    }
    public boolean eliminarTarea(String idTarea) {
        for (int i = 0; i < tareasProyecto.size(); i++) {
            Tarea t = tareasProyecto.get(i);
            if (t.getId().equals(idTarea)) {
                tareasProyecto.remove(i);
                return true;
            }
        }
        return false;
    }
}

