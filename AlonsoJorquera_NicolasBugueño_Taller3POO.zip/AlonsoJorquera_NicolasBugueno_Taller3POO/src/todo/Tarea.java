package todo;

public abstract class Tarea {
    protected Proyecto proyecto;
    protected String id;
    protected String tipo;
    protected String descripcion;
    protected String estado;
    protected Usuario usuarioResponsable;
    protected String complejidad;
    protected String fecha;

    public Tarea(Proyecto proyecto, String id, String tipo, String descripcion,
                 String estado, Usuario usuarioResponsable, String complejidad, String fecha) {
        this.proyecto = proyecto;
        this.id = id;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.estado = estado;
        this.usuarioResponsable = usuarioResponsable;
        this.complejidad = complejidad;
        this.fecha = fecha;
    }

    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public Usuario getUsuarioResponsable() {
        return usuarioResponsable;
    }

    public String getComplejidad() {
        return complejidad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }

    @Override
    public String toString() {
        return "Tarea [ID=" + id + ", Tipo=" + tipo + ", Estado=" + estado +
               ", Responsable=" + usuarioResponsable.getNombre() + ", Fecha=" + fecha + "]";
    }

	public void aceptar(VisitorTareas v) {
		// TODO Auto-generated method stub
		
	}
}
