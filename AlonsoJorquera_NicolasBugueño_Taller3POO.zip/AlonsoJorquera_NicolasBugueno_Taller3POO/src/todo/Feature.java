package todo;

public class Feature extends Tarea {

	public Feature(Proyecto proyecto, String id, String tipo, String descripcion, String estado,
			Usuario usuarioResponsable, String complejidad, String fecha) {
		super(proyecto, id, tipo, descripcion, estado, usuarioResponsable, complejidad, fecha);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void aceptar(VisitorTareas v) {
	    v.visitarFeature(this);
	}

}
