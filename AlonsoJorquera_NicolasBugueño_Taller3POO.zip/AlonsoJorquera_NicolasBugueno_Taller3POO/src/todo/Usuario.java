package todo;

public abstract class Usuario {
    protected String nombre;
    protected String contraseña;

    public Usuario(String nombre, String contraseña) {
        this.nombre = nombre;
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContraseña() {
        return contraseña;
    }
    
    public abstract void mostrarMenu();
}

