package todo;
//VER LIBRO PARA USAR FACTORY
public class UsuarioFactory {
    public static Usuario crearUsuario(String rol, String nombre, String contraseña) {
        switch (rol.toLowerCase()) {
            case "admin":
            case "administrador":
                return new Admin(nombre, contraseña);
            case "colaborador":
                return new Colaborador(nombre, contraseña);
            default:
                throw new IllegalArgumentException("Rol desconocido: " + rol);
        }
    }
}
