package todo;

public interface Sistema {
    // Funciones de admin
    void verListaProyectosYTareas();
    void agregarProyecto(String nombre, Usuario responsable);
    void eliminarProyecto(String id);
    void agregarTarea(String idProyecto, Tarea tarea);
    void eliminarTarea(String idProyecto, String idTarea);
    void asignarPrioridades(String estrategia);
    void generarReporte(String archivo);

    // Funciones de usuario
    void verProyectosDisponibles();
    void verTareasAsignadas(Usuario usuario);
    void actualizarEstadoTarea(String idTarea, String nuevoEstado);
    void aplicarVisitorTareas(VisitorTareas v);
}
