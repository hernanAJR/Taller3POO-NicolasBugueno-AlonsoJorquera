package todo;

//Nicolás Ignacio Bugueño Rementería - 20.007.300-2 - ICCI
//Alonso Hernan Jorquera Rodriguez - 20.948.058-1 - ITI

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        SistemaImpl sistema = SistemaImpl.getInstancia();

        //Cargar datos
        sistema.cargarUsuarios("usuarios.txt");
        sistema.cargarProyectos("proyectos.txt");
        sistema.cargarTareas("tareas.txt");

        Scanner teclado = new Scanner(System.in);

        //LOGIN!!!
        System.out.println("------- SISTEMA DE TASKFORGE -------");
        System.out.print("Ingrese nombre de usuario: ");
        String nombre = teclado.nextLine();
        System.out.print("Ingrese contraseña: ");
        String contraseña = teclado.nextLine();

        Usuario usuario = sistema.login(nombre, contraseña);

        if (usuario == null) {
            System.out.println("Usuario o contraseña incorrectos.");
            teclado.close();
            return;
        }

        //Menus
        boolean salir = false;
        while (!salir) {
            usuario.mostrarMenu();
            System.out.print("Seleccione una opción: ");
            int opcion = teclado.nextInt();
            teclado.nextLine();

            if (usuario instanceof Admin) {
                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese nombre del proyecto: ");
                        String nombreProyecto = teclado.nextLine();
                        sistema.agregarProyecto(nombreProyecto, usuario);
                        break;
                    case 2:
                        System.out.print("Ingrese ID del proyecto: ");
                        String idProyecto = teclado.nextLine();
                        System.out.print("Ingrese ID de la tarea: ");
                        String idTarea = teclado.nextLine();
                        System.out.print("Ingrese tipo de tarea (bug, feature o documentacion): ");
                        String tipo = teclado.nextLine();
                        System.out.print("Ingrese descripción: ");
                        String descripcion = teclado.nextLine();
                        System.out.print("Ingrese estado inicial: ");
                        String estado = teclado.nextLine();
                        System.out.print("Ingrese nombre del responsable: ");
                        String nombreResp = teclado.nextLine();
                        Usuario responsable = sistema.buscarUsuario(nombreResp);
                        System.out.print("Ingrese complejidad (baja, media o alta): ");
                        String complejidad = teclado.nextLine();
                        System.out.print("Ingrese fecha: ");
                        String fecha = teclado.nextLine();

                        Tarea tarea = null;
                        switch (tipo.toLowerCase()) {
                            case "bug":
                                tarea = new Bug(sistema.buscarProyecto(idProyecto), idTarea, tipo, descripcion, estado, responsable, complejidad, fecha);
                                break;
                            case "feature":
                                tarea = new Feature(sistema.buscarProyecto(idProyecto), idTarea, tipo, descripcion, estado, responsable, complejidad, fecha);
                                break;
                            case "documentacion":
                                tarea = new Documentacion(sistema.buscarProyecto(idProyecto), idTarea, tipo, descripcion, estado, responsable, complejidad, fecha);
                                break;
                        }
                        if (tarea != null) {
                            sistema.agregarTarea(idProyecto, tarea);
                        }
                        break;
                    case 3:
                        sistema.generarReporte("reporte.txt");
                        break;
                    case 4:
                        System.out.print("Ingrese de que manera le gustaria asignar prioridades: ");
                        String estrategia = teclado.nextLine();
                        sistema.asignarPrioridades(estrategia);
                        break;
                    case 5:
                        salir = true;
                        break;
                }
            //Usar instanceof para saber a cual corresponde    
            } else if (usuario instanceof Colaborador) {
                switch (opcion) {
                    case 1:
                        sistema.verProyectosDisponibles();
                        break;
                    case 2:
                        sistema.verTareasAsignadas(usuario);
                        break;
                    case 3:
                        System.out.print("Ingrese ID de la tarea: ");
                        String idTarea = teclado.nextLine();
                        System.out.print("Nuevo estado: ");
                        String nuevoEstado = teclado.nextLine();
                        sistema.actualizarEstadoTarea(idTarea, nuevoEstado);
                        break;
                    case 5:
                    	salir = true;
                    	break;
                    //USAR VISITOR ACA!!
                    case 4: 
                        VisitorTareas visitor = new VisitorImpl();
                        sistema.aplicarVisitorTareas(visitor);
                        break;
                }
            }
        }

        System.out.println("SALIENDO...");
        System.out.println("---------------");
        teclado.close();
    }
}
