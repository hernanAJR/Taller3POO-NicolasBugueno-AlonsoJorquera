package todo;

import java.util.ArrayList;

public class PrioridadFecha implements PrioridadStrategy {
	//Ordenar Segun Fecha
    @Override
    public void ordenar(ArrayList<Tarea> tareas) {
        for (int i = 0; i < tareas.size() - 1; i++) {
            for (int j = 0; j < tareas.size() - i - 1; j++) {
                if (tareas.get(j).getFecha().compareTo(tareas.get(j+1).getFecha()) > 0) {
                    Tarea temp = tareas.get(j);
                    tareas.set(j, tareas.get(j+1));
                    tareas.set(j+1, temp);
                }
            }
        }
    }
}
