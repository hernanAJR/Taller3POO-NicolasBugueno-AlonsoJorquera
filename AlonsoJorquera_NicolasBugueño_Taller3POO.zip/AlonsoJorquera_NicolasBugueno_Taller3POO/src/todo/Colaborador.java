package todo;

public class Colaborador extends Usuario {
	String rol;
    public Colaborador(String nombre, String contraseña) {
        super(nombre, contraseña);
        this.rol = "colaborador";
        
    }

    @Override
    public void mostrarMenu() {
        System.out.println("------ MENU COLABORADOR ------:");
        System.out.println("1. Ver Proyectos");
        System.out.println("2. Ver Tareas Asignadas");
        System.out.println("3. Actualizar Estado de Tarea");
        System.out.println("4. Salir");
    }
}
