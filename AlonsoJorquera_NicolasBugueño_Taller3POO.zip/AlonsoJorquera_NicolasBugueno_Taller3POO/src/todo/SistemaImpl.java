package todo;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class SistemaImpl implements Sistema {
    private static SistemaImpl instancia;
    private ArrayList<Usuario> usuarios;
    private ArrayList<Proyecto> proyectos;

    // Constructor privado SINGLETON
    private SistemaImpl() {
        usuarios = new ArrayList<>();
        proyectos = new ArrayList<>();
    }

    // SINGLETON
    public static SistemaImpl getInstancia() {
        if (instancia == null) {
            instancia = new SistemaImpl();
        }
        return instancia;
    }

    //USAR FACTORY
    public void cargarUsuarios(String archivo) {
    	 try (Scanner sc = new Scanner(new File(archivo))) {
             while (sc.hasNextLine()) {
                 String linea = sc.nextLine();
                 String[] partes = linea.split(";");

                 if (partes.length >= 3) {
                     String nombre = partes[0];
                     String contraseña = partes[1];
                     String rol = partes[2];

                     Usuario u = UsuarioFactory.crearUsuario(rol, nombre, contraseña);
                     usuarios.add(u);
                 }
             }
         } catch (FileNotFoundException e) {
             System.out.println("Archivo de usuarios no encontrado: " + e.getMessage());
         }
    }

    // LEER ARCHIVO PROYECTOS
    public void cargarProyectos(String archivo) {
        try (Scanner archivoPro = new Scanner(new File(archivo))) {
            while (archivoPro.hasNextLine()) {
                String linea = archivoPro.nextLine();
                String[] partes = linea.split(";");

                if (partes.length >= 3) {
                    String id = partes[0];
                    String nombreProyecto = partes[1];
                    String nombreResponsable = partes[2];

                    Usuario responsable = buscarUsuario(nombreResponsable);
                    Proyecto p = new Proyecto(id, responsable);
                    proyectos.add(p);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo de proyectos no encontrado" );
        }
    }

    //Carga Tareas
    public void cargarTareas(String arch) {
    	try (Scanner archivo = new Scanner(new File(arch))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                if (partes.length >= 8) {
                    String idProyecto = partes[0];
                    String idTarea = partes[1];
                    String tipo = partes[2];
                    String descripcion = partes[3];
                    String estado = partes[4];
                    String nombreResponsable = partes[5];
                    String complejidad = partes[6];
                    String fecha = partes[7];

                    Proyecto proyecto = buscarProyecto(idProyecto);
                    Usuario responsable = buscarUsuario(nombreResponsable);

                    Tarea tarea = null;
                    switch (tipo.toLowerCase()) {
                        case "bug":
                            tarea = new Bug(proyecto, idTarea, tipo, descripcion, estado, responsable, complejidad, fecha);
                            break;
                        case "feature":
                            tarea = new Feature(proyecto, idTarea, tipo, descripcion, estado, responsable, complejidad, fecha);
                            break;
                        case "documentacion":
                            tarea = new Documentacion(proyecto, idTarea, tipo, descripcion, estado, responsable, complejidad, fecha) ;
                            break;
                    }

                    if (tarea != null && proyecto != null) {
                        proyecto.agregarTarea(tarea);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo de tareas no encontrado: " + e.getMessage());
        }
    }
    
    
    
    
    /**
     * Recorre todos los proyectos cargados en el sistema
     * y despliega sus datos junto con las tareas que contienen.
     */
    @Override
    public void verListaProyectosYTareas() {
        for (Proyecto x : proyectos) {
            System.out.println("Proyecto: " + x.getId() + " - Responsable: " + x.getUsuarioResponsable().getNombre());
            for (Tarea y : x.getTareasProyecto()) {
                System.out.println("   Tarea: " + y.getId() + " - " + y.getDescripcion() + " [" + y.getEstado() + "]");
            }
        }
    }


    /**
     * Agrega un nuevo proyecto al sistema.
     * 
     * @param nombre Nombre del proyecto a crear.
     * @param responsable Usuario responsable del proyecto.
     */
    @Override
    public void agregarProyecto(String nombre, Usuario responsable) {
        String id = "P" + (proyectos.size() + 1); //CREAR ID
        Proyecto p = new Proyecto(id, responsable);
        proyectos.add(p);
        System.out.println("Proyecto agregado: " + nombre + " con ID " + id);
    }


    /**
     * Elimina un proyecto del sistema junto con todas sus tareas asociadas.
     * Si el proyecto existe, se elimina de la lista interna de tares. 
     * En caso contrario, se muestra un mensaje de error.
     * @param id Identificador único del proyecto a eliminar.
     */
    @Override
    public void eliminarProyecto(String id) {
        Proyecto proyecto = buscarProyecto(id);
        if (proyecto != null) {
            proyectos.remove(proyecto);
            System.out.println("Proyecto eliminado: " + id);
        } else {
            System.out.println("Proyecto no encontrado.");
        }
    }


    /**
     * Agrega una nueva tarea a un proyecto específico.
     *
     * Busca el proyecto por su ID y añade la tarea a su lista interna.
     * Si el proyecto no existe, muestra un mensaje de error.
     * @param idProyecto Identificador único del proyecto al que se agregará la tarea.
     * @param tarea Objeto de tipo Tarea (Bug, Feature, Documentacion).
     */
    @Override
    public void agregarTarea(String idProyecto, Tarea tarea) {
        Proyecto proyecto = buscarProyecto(idProyecto);
        if (proyecto != null) {
            proyecto.agregarTarea(tarea);
            System.out.println("Tarea agregada al proyecto " + idProyecto);
        } else {
            System.out.println("Proyecto no encontrado.");
        }
    }


    /**
     * Busca el proyecto y elimina la tarea indicada de su lista interna.
     * Si el proyecto o la tarea no existen, muestra un mensaje de error.</p>
     * @param idProyecto Identificador único del proyecto que contiene la tarea.
     * @param idTarea Identificador único de la tarea a eliminar.  
     */
    @Override
    public void eliminarTarea(String idProyecto, String idTarea) {
        Proyecto proyecto = buscarProyecto(idProyecto);
        if (proyecto != null) {
            proyecto.eliminarTarea(idTarea);
            System.out.println("Tarea eliminada: " + idTarea);
        } else {
            System.out.println("Proyecto no encontrado.");
        }
    }


    /**
     *Recorre todos los proyectos y aplica la estrategia de ordenamiento
     * definida en la clase Proyecto usando el patrón Strategy.
     * @param estrategia Estrategia de ordenamiento ("fecha", "impacto", "complejidad").
     * 
     */
    @Override
    public void asignarPrioridades(String estrategia) {
        for (Proyecto x : proyectos) {
            x.ordenarTareas(estrategia);
        }
        System.out.println("Prioridades asignadas con estrategia: " + estrategia);
    }

    
    /**
     * USAR FILEWRITER COMO EL TALLER ANTERIOR
     * Genera un archivo de reporte con información detallada de proyectos y tareas.
     * 
     * @param archivo Nombre del archivo de salida (ejemplo: "reporte.txt").
     */
    @Override
    public void generarReporte(String archivo) {
        try (FileWriter escritor = new FileWriter(archivo)) {
            for (Proyecto p : proyectos) {
                escritor.write("Proyecto: " + p.getId() + " - Responsable: " + p.getUsuarioResponsable().getNombre() + "\n");
                for (Tarea t : p.getTareasProyecto()) {
                    escritor.write("   Tarea: " + t.getId() + " - " + t.getDescripcion() + " [" + t.getEstado() + "]\n");
                }
            }
            System.out.println("Reporte generado en " + archivo);
        } catch (IOException e) {
            System.out.println("Error al generar reporte: " + e.getMessage());
        }
    }

    /**
     * Muestra en consola todos los proyectos disponibles en el sistema.
     */
    @Override
    public void verProyectosDisponibles() {
        for (Proyecto p : proyectos) {
            System.out.println("Proyecto: " + p.getId() +
                               " - Responsable: " + p.getUsuarioResponsable().getNombre());
        }
    }

    /**
     * Muestra todas las tareas asignadas a un colaborador específico.
     *
     * @param usuario Usuario colaborador cuyas tareas se desean visualizar.
     */
    @Override
    public void verTareasAsignadas(Usuario usuario) {
        for (Proyecto x : proyectos) {
            for (Tarea t : x.getTareasProyecto()) {
                if (t.getUsuarioResponsable().equals(usuario)) {
                    System.out.println("Tarea asignada: " + t.getId() +
                                       " - " + t.getDescripcion() +
                                       " [" + t.getEstado() + "]");
                }
            }
        }
    }
	/**
	 * Actualiza el estado de una tarea específica.
	 *
	 * @param idTarea Identificador único de la tarea a actualizar.
	 * @param nuevoEstado Nuevo estado de la tarea (ejemplo: "Pendiente", "En progreso", "Completada").
	 */
	@Override
	public void actualizarEstadoTarea(String idTarea, String nuevoEstado) {
	    for (Proyecto p : proyectos) {
	        for (Tarea t : p.getTareasProyecto()) {
	            if (t.getId().equals(idTarea)) {
	                t.setEstado(nuevoEstado);
	                System.out.println("Estado actualizado de tarea " + idTarea +
	                                   " a " + nuevoEstado);
	                return;
	            }
	        }
	    }
	    System.out.println("Tarea no encontrada: " + idTarea);
	}

	/**
	 * Aplica el visitor sobre todas las tareas de todos los proyectos.
	 *
	 * @param visitor Nuestro visitor a usar.
	 */
	@Override
	public void aplicarVisitorTareas(VisitorTareas visitor) {
	    for (Proyecto p : proyectos) {
	        for (Tarea t : p.getTareasProyecto()) {
	            t.aceptar(visitor);
	        }
	    }
	}
	//LOGIN
	/**
	 * Valida las credenciales de un usuario en el sistema.
	 *
	 * @param nombre Nombre del usuario.
	 * @param contraseña Contraseña del usuario.
	 * @return Usuario si las credenciales son correctas, null en caso contrario.
	 */
	public Usuario login(String nombre, String contraseña) {
	    for (Usuario u : usuarios) {
	        if (u.getNombre().equals(nombre) && u.getContraseña().equals(contraseña)) {
	            return u;
	        }
	    }
	    return null;
	}

	//UTILIDADES
    public Usuario buscarUsuario(String nombre) {
        for (Usuario u : usuarios) {
            if (u.getNombre().equals(nombre)) {
                return u;
            }
        }
        return null;
    }

    public Proyecto buscarProyecto(String id) {
        for (Proyecto p : proyectos) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }
}

