package todo;

public interface VisitorTareas {
	//Nos ahorra ifs
    void visitarBug(Bug b);
    void visitarFeature(Feature f);
    void visitarDocumentacion(Documentacion d);

	
}
